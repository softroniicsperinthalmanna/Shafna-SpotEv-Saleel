-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2023 at 12:07 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spot_ev`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaint_tb`
--

CREATE TABLE `complaint_tb` (
  `complaint_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `complain_type` varchar(100) NOT NULL,
  `other_complaints` varchar(100) NOT NULL,
  `description` varchar(250) NOT NULL,
  `date` datetime NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaint_tb`
--

INSERT INTO `complaint_tb` (`complaint_id`, `station_id`, `user_id`, `complain_type`, `other_complaints`, `description`, `date`, `status`) VALUES
(1, 29, 12, 'Slow Charging', '2023-07-03 12:52:52.854740', 'qwertyuilkmnjkmdnfjdks', '2023-07-02 18:47:34', ''),
(2, 19, 12, 'Charger Faculty', '2023-07-03 13:02:47.863417', 'Charging and front shocker regarding, Wrong Product sold with safety, Quality and Security compromised, battery mileage issue, Battery Issues, Battery replacement issue', '1900-01-02 18:47:47', ''),
(3, 19, 12, 'Slow Charging', '[Charging and front shocker regarding, Wrong Product sold with safety, Quality and Security compromi', 'avbnjgfd', '2023-07-03 13:05:05', ''),
(4, 19, 12, 'Charger Faculty', '[Charging and front shocker regarding, Wrong Product sold with safety, Quality and Security compromi', 'avbnjgfd', '2023-07-03 13:06:16', ''),
(5, 19, 12, 'Charger Faculty', '[Charging and front shocker regarding, Wrong Product sold with safety, Quality and Security compromi', 'avbnjgfd', '2023-07-03 13:09:36', ''),
(6, 28, 12, 'Network Issue', '[Charging and front shocker regarding, Wrong Product sold with safety, Quality and Security compromi', 'asdfhklmnbbccxzzswwrtyuoopllkhg', '2023-07-03 13:10:12', '');

-- --------------------------------------------------------

--
-- Table structure for table `login_tb`
--

CREATE TABLE `login_tb` (
  `login_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `user_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_tb`
--

INSERT INTO `login_tb` (`login_id`, `email`, `password`, `user_type`) VALUES
(1, 'shafna.pmna@gmail.com', 'shaf1234', 'station'),
(2, 'shafna.pmna@gmail.com', 'shaf1234', 'station'),
(3, 'shafna.pmna@gmail.com', 'shaf1234', 'station'),
(4, 'sss@gmail.com', 'sss123', 'station'),
(5, 'sss@gmail.com', 'sss123', 'station'),
(6, 'sss@gmail.com', 'sss123', 'station'),
(7, 'tansi@gmail.com', 'tanseer', 'user'),
(8, 't@gmail.com', 't123', 'user'),
(9, 'swalih@gmail.com', 'swalih123', 'station'),
(10, 'shastation@gmail.com', 'sha123', 'station'),
(11, 'dilumolu@gmail.com', '123', 'user'),
(12, 'shaf@gmail.com', '123', 'user'),
(13, '', '123123', 'user'),
(14, '', '123', 'user'),
(15, '', 'aa123', 'user'),
(16, 'shafna.pmna@gmail.com', '123456898', 'user'),
(17, 'shaf@gmail.com', 'shaf12345', 'user'),
(18, 'vtestby@gmail.com', '123456789', 'station'),
(19, 'chargeby@gmail.com', 'chargeby123', 'station'),
(20, 'vestBy@gmail.com', '112233445', 'station'),
(21, 'vestBy@gmail.com', '11223445', 'station'),
(22, 'vestBy@gmail.com', '1122335', 'station'),
(23, 'liyaniya@gmail.com', 'liya12345', 'user'),
(24, 'www.22204255vt@gmail.com', '123123123', 'user'),
(25, 'www.qwertyuiopasdfghjklzxcvbnm@gmail.com', '123123123', 'user'),
(26, 'hshhs', 'bhhs56677', 'user'),
(27, 'evstation@gmail.com', 'ev1234567', 'station'),
(28, 'www.qwertyuiopasdfghjklzxcvbnm@gmail.com', '123123123', 'station'),
(29, 'electro@gmail.com', '112233445', 'station');

-- --------------------------------------------------------

--
-- Table structure for table `slot_tb`
--

CREATE TABLE `slot_tb` (
  `slot_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `connector_type` varchar(50) NOT NULL,
  `power_capacity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slot_tb`
--

INSERT INTO `slot_tb` (`slot_id`, `station_id`, `connector_type`, `power_capacity`, `price`) VALUES
(1, 8, 'Chademo', 100, 100),
(2, 19, 'Chademo', 100, 100),
(3, 18, 'Chademo', 100, 100),
(4, 18, 'CCS2', 22, 200),
(12, 18, 'CCS', 20, 200),
(13, 18, 'GB/T', 50, 100),
(14, 18, 'TYPE-2', 20, 100),
(15, 18, 'TYPE-2', 50, 150),
(16, 18, 'CCS2', 50, 200);

-- --------------------------------------------------------

--
-- Table structure for table `station_tb`
--

CREATE TABLE `station_tb` (
  `station_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `place` varchar(50) NOT NULL,
  `location` varchar(20) NOT NULL,
  `lattitude` float NOT NULL,
  `longitude` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `station_tb`
--

INSERT INTO `station_tb` (`station_id`, `login_id`, `name`, `mobile_no`, `place`, `location`, `lattitude`, `longitude`) VALUES
(1, 18, 'Vestyby', 9900887711, 'Angadipuram', 'Angadipuram,X6H3+52P', 10.9779, 76.2026),
(2, 19, 'chargeby', 6633009987, '', 'Angadipuram,X6H3+533', 10.9779, 76.2026),
(3, 9, 'Swali Station', 9876543210, '', 'Pattikkad', 0.3345, 12.7708),
(4, 10, 'ShaStation', 8790654321, '', 'Perithalmanna', 60.9887, 49.7654),
(5, 5, 'VestyBy', 9900887766, '', 'Angadipuram,X6H3+52P', 10.9779, 76.2026),
(6, 21, 'VestyBy', 9900965240, '', 'Angadipuram,X6H3+533', 10.9779, 76.2026),
(7, 22, 'VestyBy', 9900887766, 'Nenmini', 'Nenmini,26RF+VQ8,,', 11.0425, 76.2252),
(8, 27, 'Evsatation', 7896541230, '', 'Angadipuram,X6H3+533', 10.9779, 76.2026),
(9, 28, 'pmna', 9074230412, 'Angadipuram', 'Angadipuram,X6H3+533', 10.9779, 76.2026),
(10, 29, 'ElectroStation', 8065329865, 'Nenmini', 'Nenmini,26RF+VQ8,,', 11.0417, 76.2253);

-- --------------------------------------------------------

--
-- Table structure for table `user_register_tb`
--

CREATE TABLE `user_register_tb` (
  `reg_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_register_tb`
--

INSERT INTO `user_register_tb` (`reg_id`, `name`, `mobile_no`, `login_id`) VALUES
(1, 'shafna', 8289816332, 2),
(2, 'sijil', 9087650909, 6),
(3, 'Thanseer', 9900887651, 7),
(4, 'thansii', 9900088765, 8),
(5, '', 0, 9),
(6, 'shafna', 9900765432, 10),
(7, 'Dilumoluu', 9807654355, 11),
(8, 'Shafna', 8899509843, 12),
(9, 'vgjj', 0, 13),
(10, '', 0, 14),
(11, '', 0, 15),
(12, 'shafna', 0, 16),
(13, 'shaf', 9900903513, 17),
(14, 'Liyana Niyas', 9924365278, 23),
(15, 'Mohammed Swalih VT', 9074230412, 24),
(16, 'vt', 1234567890, 25),
(17, 'hshhs', 964649, 26);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaint_tb`
--
ALTER TABLE `complaint_tb`
  ADD PRIMARY KEY (`complaint_id`);

--
-- Indexes for table `login_tb`
--
ALTER TABLE `login_tb`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `slot_tb`
--
ALTER TABLE `slot_tb`
  ADD PRIMARY KEY (`slot_id`);

--
-- Indexes for table `station_tb`
--
ALTER TABLE `station_tb`
  ADD PRIMARY KEY (`station_id`);

--
-- Indexes for table `user_register_tb`
--
ALTER TABLE `user_register_tb`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaint_tb`
--
ALTER TABLE `complaint_tb`
  MODIFY `complaint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `login_tb`
--
ALTER TABLE `login_tb`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `slot_tb`
--
ALTER TABLE `slot_tb`
  MODIFY `slot_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `station_tb`
--
ALTER TABLE `station_tb`
  MODIFY `station_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_register_tb`
--
ALTER TABLE `user_register_tb`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
