-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2023 at 10:22 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spot_ev`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaint_tb`
--

CREATE TABLE `complaint_tb` (
  `complaint_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `complain_type` varchar(100) NOT NULL,
  `description` varchar(250) NOT NULL,
  `date` datetime NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `location_tb`
--

CREATE TABLE `location_tb` (
  `location_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `place` varchar(50) NOT NULL,
  `location` varchar(100) NOT NULL,
  `lattitude` float NOT NULL,
  `longitude` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `location_tb`
--

INSERT INTO `location_tb` (`location_id`, `station_id`, `place`, `location`, `lattitude`, `longitude`) VALUES
(1, 8, 'Perithalmanna', 'Perithalmanna,palam,eettthh', 34.09, 89.765),
(2, 18, 'Angadipuram', 'Angadipuram,X6H3+533,Chanthully Paadam,', 10.9779, 76.2026268),
(3, 19, 'Angadipuram', 'Angadipuram,X6H3+533,Chanthully Paadam,', 10.9779, 76.2026131),
(4, 5, 'Angadipuram', 'Angadipuram,X6H3+52P,Chanthully Paadam,', 10.9779, 76.2026223),
(5, 21, 'Angadipuram', 'Angadipuram,X6H3+533,Chanthully Paadam,', 10.9779, 76.2026233),
(6, 15, 'Angadipuram', 'Angadipuram,X6H3+52P,Chanthully Paadam,', 10.9779, 76.2026265);

-- --------------------------------------------------------

--
-- Table structure for table `login_tb`
--

CREATE TABLE `login_tb` (
  `login_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `user_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_tb`
--

INSERT INTO `login_tb` (`login_id`, `email`, `password`, `user_type`) VALUES
(1, 'shafna.pmna@gmail.com', 'shaf1234', 'station'),
(2, 'shafna.pmna@gmail.com', 'shaf1234', 'station'),
(3, 'shafna.pmna@gmail.com', 'shaf1234', 'station'),
(4, 'sss@gmail.com', 'sss123', 'station'),
(5, 'sss@gmail.com', 'sss123', 'station'),
(6, 'sss@gmail.com', 'sss123', 'station'),
(7, 'tansi@gmail.com', 'tanseer', 'user'),
(8, 't@gmail.com', 't123', 'user'),
(9, 'swalih@gmail.com', 'swalih123', 'station'),
(10, 'shastation@gmail.com', 'sha123', 'station'),
(11, 'dilumolu@gmail.com', '123', 'user'),
(12, 'shaf@gmail.com', '123', 'user'),
(13, '', '123123', 'user'),
(14, '', '123', 'user'),
(15, '', 'aa123', 'user'),
(16, 'shafna.pmna@gmail.com', '123456898', 'user'),
(17, 'shaf@gmail.com', 'shaf12345', 'user'),
(18, 'vtestby@gmail.com', '', 'station'),
(19, 'chargeby@gmail.com', 'chargeby123', 'station'),
(20, 'vestBy@gmail.com', '112233445', 'station'),
(21, 'vestBy@gmail.com', '112233445', 'station'),
(22, 'vestBy@gmail.com', '112233445', 'station');

-- --------------------------------------------------------

--
-- Table structure for table `slot_tb`
--

CREATE TABLE `slot_tb` (
  `slot_id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `connector_type` varchar(50) NOT NULL,
  `power_capacity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `slot_tb`
--

INSERT INTO `slot_tb` (`slot_id`, `station_id`, `connector_type`, `power_capacity`, `price`) VALUES
(1, 8, 'Chademo', 100, 100),
(2, 19, 'Chademo', 100, 100),
(3, 18, 'Chademo', 100, 100),
(4, 18, '  CCS2', 22, 200),
(12, 18, 'CCS', 20, 200),
(13, 18, 'GB/T', 50, 100),
(14, 18, 'TYPE-2', 20, 100),
(15, 18, 'TYPE-2', 50, 150),
(16, 18, 'CCS2', 50, 200);

-- --------------------------------------------------------

--
-- Table structure for table `station_tb`
--

CREATE TABLE `station_tb` (
  `station_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `location` varchar(20) NOT NULL,
  `lattitude` float NOT NULL,
  `longitude` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `station_tb`
--

INSERT INTO `station_tb` (`station_id`, `login_id`, `name`, `mobile_no`, `location`, `lattitude`, `longitude`) VALUES
(1, 18, 'Vestyby', 9900887711, '', 0, 0),
(2, 19, 'chargeby', 6633009987, 'Angadipuram,X6H3+533', 10.9779, 76.2026),
(3, 9, 'Swali Station', 9876543210, 'Pattikkad', 0.3345, 12.7708),
(4, 10, 'ShaStation', 8790654321, 'Perithalmanna', 60.9887, 49.7654),
(5, 5, 'VestyBy', 9900887766, 'Angadipuram,X6H3+52P', 10.9779, 76.2026),
(6, 21, 'VestyBy', 9900965240, 'Angadipuram,X6H3+533', 10.9779, 76.2026),
(7, 22, 'VestyBy', 9900887766, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_register_tb`
--

CREATE TABLE `user_register_tb` (
  `reg_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_register_tb`
--

INSERT INTO `user_register_tb` (`reg_id`, `name`, `mobile_no`, `login_id`) VALUES
(1, 'shafna', 8289816332, 2),
(2, 'sijil', 9087650909, 6),
(3, 'Thanseer', 9900887651, 7),
(4, 'thansii', 9900088765, 8),
(5, '', 0, 9),
(6, 'shafna', 9900765432, 10),
(7, 'Dilumoluu', 9807654355, 11),
(8, 'Shafna', 8899509843, 12),
(9, 'vgjj', 0, 13),
(10, '', 0, 14),
(11, '', 0, 15),
(12, 'shafna', 0, 16),
(13, 'shaf', 9900903513, 17);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaint_tb`
--
ALTER TABLE `complaint_tb`
  ADD PRIMARY KEY (`complaint_id`);

--
-- Indexes for table `location_tb`
--
ALTER TABLE `location_tb`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `login_tb`
--
ALTER TABLE `login_tb`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `slot_tb`
--
ALTER TABLE `slot_tb`
  ADD PRIMARY KEY (`slot_id`);

--
-- Indexes for table `station_tb`
--
ALTER TABLE `station_tb`
  ADD PRIMARY KEY (`station_id`);

--
-- Indexes for table `user_register_tb`
--
ALTER TABLE `user_register_tb`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaint_tb`
--
ALTER TABLE `complaint_tb`
  MODIFY `complaint_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `location_tb`
--
ALTER TABLE `location_tb`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `login_tb`
--
ALTER TABLE `login_tb`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `slot_tb`
--
ALTER TABLE `slot_tb`
  MODIFY `slot_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `station_tb`
--
ALTER TABLE `station_tb`
  MODIFY `station_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_register_tb`
--
ALTER TABLE `user_register_tb`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
