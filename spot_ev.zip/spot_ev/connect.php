<?php
$con=new mysqli('localhost','root','','spot_ev');
// if($con){
//     echo "Success";
// }
// else{
//     echo "Failed";
// }
?>