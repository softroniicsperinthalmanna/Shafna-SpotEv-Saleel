-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2023 at 09:58 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spot_ev`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_tb`
--

CREATE TABLE `login_tb` (
  `login_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(25) NOT NULL,
  `user_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_tb`
--

INSERT INTO `login_tb` (`login_id`, `email`, `password`, `user_type`) VALUES
(1, 'shafna.pmna@gmail.com', 'shaf1234', 'station'),
(2, 'shafna.pmna@gmail.com', 'shaf1234', 'station'),
(3, 'shafna.pmna@gmail.com', 'shaf1234', 'station'),
(4, 'sss@gmail.com', 'sss123', 'station'),
(5, 'sss@gmail.com', 'sss123', 'station'),
(6, 'sss@gmail.com', 'sss123', 'station'),
(7, 'tansi@gmail.com', 'tanseer', 'user'),
(8, 't@gmail.com', 't123', 'station'),
(9, 'swalih@gmail.com', 'swalih123', 'station'),
(10, 'shastation@gmail.com', 'sha123', 'station'),
(11, '', '123', 'user'),
(12, '', '123', 'user'),
(13, '', '123123', 'user'),
(14, '', '123', 'user'),
(15, '', 'aa123', 'user'),
(16, 'shafna.pmna@gmail.com', '123456898', 'user'),
(17, 'shaf@gmail.com', 'shaf12345', 'user'),
(18, 'test@gmail.com', '', 'station'),
(19, 'chargeby@gmail.com', 'chargeby123', 'station');

-- --------------------------------------------------------

--
-- Table structure for table `slot_tb`
--

CREATE TABLE `slot_tb` (
  `slot_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `slot_no` int(11) NOT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 1,
  `connector_type` varchar(50) NOT NULL,
  `power_capacity` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `station_tb`
--

CREATE TABLE `station_tb` (
  `station_id` int(11) NOT NULL,
  `login_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `location` varchar(20) NOT NULL,
  `lattitude` float NOT NULL,
  `longitude` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `station_tb`
--

INSERT INTO `station_tb` (`station_id`, `login_id`, `name`, `mobile_no`, `location`, `lattitude`, `longitude`) VALUES
(1, 18, 'testing', 9900887711, '', 0, 0),
(2, 19, 'chargeby', 6633009988, '', 0, 0),
(3, 9, 'Swali Station', 9876543210, 'Pattikkad', 0.3345, 12.7708),
(4, 10, 'ShaStation', 8790654321, 'Perithalmanna', 60.9887, 49.7654);

-- --------------------------------------------------------

--
-- Table structure for table `user_register_tb`
--

CREATE TABLE `user_register_tb` (
  `reg_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `login_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_register_tb`
--

INSERT INTO `user_register_tb` (`reg_id`, `name`, `mobile_no`, `login_id`) VALUES
(1, 'shafna', 8289816332, 2),
(2, 'sijil', 9087650909, 6),
(3, 'Thanseer', 9900887651, 7),
(4, 'thansii', 9900088765, 8),
(5, '', 0, 9),
(6, 'shafna', 9900765432, 10),
(7, '', 0, 11),
(8, '', 0, 12),
(9, 'vgjj', 0, 13),
(10, '', 0, 14),
(11, '', 0, 15),
(12, 'shafna', 0, 16),
(13, 'shaf', 9900903513, 17);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_tb`
--
ALTER TABLE `login_tb`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `slot_tb`
--
ALTER TABLE `slot_tb`
  ADD PRIMARY KEY (`slot_id`);

--
-- Indexes for table `station_tb`
--
ALTER TABLE `station_tb`
  ADD PRIMARY KEY (`station_id`);

--
-- Indexes for table `user_register_tb`
--
ALTER TABLE `user_register_tb`
  ADD PRIMARY KEY (`reg_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_tb`
--
ALTER TABLE `login_tb`
  MODIFY `login_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `slot_tb`
--
ALTER TABLE `slot_tb`
  MODIFY `slot_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `station_tb`
--
ALTER TABLE `station_tb`
  MODIFY `station_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_register_tb`
--
ALTER TABLE `user_register_tb`
  MODIFY `reg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
